import data from './data'
export default {
  namespace: 'model',
  state: {
    //originData
    data,
    //data after sorted
    resortedData: [],
    //the column count showing on the page
    columnCount: 5
  },
  reducers: {
    sort(state, { payload }) {
      return {...state, resortedData: payload}
    },
  },
  effects: {
    *resort({payload}, {call, put, select}) {
      console.log('payload', payload)
      let columnCount = yield select(state => state.model.columnCount);
      let list = yield select(state => state.model.data);
      if(payload && payload.inputValue) {
        list = list.filter(item => item.name == payload.inputValue);
        //console.log('list', list)
      }
      let clientWidth = document.body.clientWidth;
      if(clientWidth<768) {
        columnCount = 1;
      } else if(clientWidth>=768 && clientWidth<1024) {
        columnCount = 3;
      } else if(clientWidth>=768 && clientWidth<1366) {
        columnCount = 4;
      } else {
      }
      let flexList = [];
      for (let i = 0; i < columnCount; i++) {
        flexList.push([]);
        for (let j = i; j < list.length; j += columnCount) {
          flexList[i].push(list[j]);
        }
      }
      yield put({type: 'sort',payload: flexList});
    }
  },
  subscriptions:{
    setup({dispatch}) {
      dispatch({
        type: 'resort'
      });
    }
  }
};
