import React from 'react';
import placeholder from './logo192.png'
class DefaultImage extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      src: placeholder,
      srcReal: this.props.srcReal
    }
  }

  handleImageLoaded() {
    //console.log(this.props.src1)
    let image = new Image();
    image.src = this.props.srcReal;
    image.onload = ()=> {
      this.setState({
        src: this.props.srcReal
      });
    }
  }

  handleImageErrored() {
    console.log('error')
    //加载失败
    this.setState({
      src: placeholder
    });
  }

  render() {
    let props = this.props;
    let {src} = this.state;
    return (
      <img
        {...props}
        src={src}
        onLoad={this.handleImageLoaded.bind(this)}
        onError={this.handleImageErrored.bind(this)}
      />
    );
  }
}

export default DefaultImage;
