import React, {useState,useEffect,PureComponent} from 'react';
import './App.scss';
import { connect } from 'dva';

import DefaultImage from "./img";

const App = ({resortedData, dispatch, data}) => {
  const changeData=(e)=>{
    dispatch({
      type: 'model/resort',
      payload: {
        inputValue : e.target.value
      }
    });
  }
  const handleResize = ()=> {

    dispatch({
      type: 'model/resort'
    });
  }
  useEffect(() => {
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, []);
  return (
    <div className='app'>
      <div className='filter'>
        <div className='input_wrapper'>
          <i></i>
          <input type='text' onChange={(e)=> changeData(e)} />
        </div>
      </div>
      <div className='test'>
        {
          resortedData.map((column, index) => {
            return (
              <div className='column' key={index + "column"}>
                {
                  column.map((item) => {
                    return (
                      <div className='item'>
                        <DefaultImage srcReal={item.src}
                             key={item._id + "item"}
                        />
                        <span>{item.name}</span>
                      </div>
                    )
                  })
                }
              </div>
            )
          })
        }
      </div>
    </div>
  );
};

// class App extends PureComponent {
//   constructor(props) {
//     super(props);
//   }
//   render() {
//       console.log('props', this.props)
//       return(
//         <div>11111</div>
//       )
//   }
//
// }

export default connect(({ model }) => ({
  ...model,
}))(App);

